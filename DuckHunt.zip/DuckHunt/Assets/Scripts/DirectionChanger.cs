﻿using UnityEngine;
using System.Collections;

public class DirectionChanger : MonoBehaviour 
{
	public enum DirChanger{Horizontal,Vertical};
	public DirectionChanger changer;
	
	void OnCollisionEnter(Collision hit)
	{
		if(hit.transform.tag == "Duck")
		{
			//create duckmovement varible. Assign using getComponent of hit
			
			if(changer == DirChanger.Horizontal)
			{
				// duckmovement carible and call the directionchanger function. new vector3(-1,1,0)
			}
			if(changer == DirChanger.Vertical)
			{
				// duckmovement carible and call the directionchanger function. new vector3(-1,1,0)
			}
		}
	}


}
